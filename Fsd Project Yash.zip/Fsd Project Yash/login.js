
const loginForm = document.getElementById("loginForm");

loginForm.addEventListener("submit", function(event) {

    event.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const errorMessage = document.getElementById("errorMessage");

    const correctEmail = "admin@classclockwork.com";
    const correctPassword = "admin123";

    if (email === correctEmail && password === correctPassword) {

        errorMessage.style.color = "green";
        errorMessage.textContent = "Login successful!";

        // Open dashboard
        window.location.href = "index.html";

    } else {

        errorMessage.style.color = "red";
        errorMessage.textContent = "Invalid email or password!";

    }

});
