
const DAYS = ["Monday","Tuesday","Wednesday","Thursday","Friday"];
const PERIODS = [
  "09:00 – 10:00","10:00 – 11:00","11:00 – 12:00",
  "12:00 – 01:00","02:00 – 03:00","03:00 – 04:00"
];

const defaultData = {
  faculty: [
    {id:1,name:"Dr. A. Sharma",department:"Computer Science",max:18,days:[0,1,2,3,4]},
    {id:2,name:"Prof. Meera Rao",department:"Computer Science",max:16,days:[0,1,2,3,4]},
    {id:3,name:"Mr. Kiran Kumar",department:"Mathematics",max:16,days:[0,1,2,3,4]},
    {id:4,name:"Dr. Priya Nair",department:"Electronics",max:18,days:[0,1,2,3,4]},
    {id:5,name:"Ms. Sneha Reddy",department:"English",max:14,days:[0,1,2,3,4]}
  ],

  rooms: [
    {id:1,name:"Room 101",type:"Classroom",capacity:60,equipment:"Projector"},
    {id:2,name:"Room 102",type:"Classroom",capacity:60,equipment:"Projector, Smart board"},
    {id:3,name:"CS Lab 1",type:"Laboratory",capacity:35,equipment:"Computers"},
    {id:4,name:"Electronics Lab",type:"Laboratory",capacity:30,equipment:"Circuit kits"}
  ],

  subjects: [
    {id:1,name:"Data Structures",code:"CS201",faculty:1,batch:"CSE-A",periods:3,type:"Lecture",students:55},
    {id:2,name:"Database Systems",code:"CS202",faculty:2,batch:"CSE-A",periods:3,type:"Lecture",students:52},
    {id:3,name:"Operating Systems Lab",code:"CS203L",faculty:1,batch:"CSE-A",periods:3,type:"Lab",students:30},
    {id:4,name:"Mathematics III",code:"MA201",faculty:3,batch:"CSE-A",periods:3,type:"Lecture",students:55},
    {id:5,name:"Digital Electronics",code:"EC201",faculty:4,batch:"CSE-A",periods:2,type:"Lecture",students:50},
    {id:6,name:"Digital Systems Lab",code:"EC202L",faculty:4,batch:"CSE-A",periods:2,type:"Lab",students:28},
    {id:7,name:"Professional English",code:"EN201",faculty:5,batch:"CSE-A",periods:2,type:"Tutorial",students:55},
    {id:8,name:"Python Programming",code:"CS204",faculty:2,batch:"CSE-B",periods:3,type:"Lecture",students:48}
  ],
  schedule:[]
};

let data = loadData();
let draggedId = null;
let toastTimer;

function loadData(){
  try{
    return JSON.parse(localStorage.getItem("classclockworkData")) || JSON.parse(JSON.stringify(defaultData));
  }catch(e){
    return JSON.parse(JSON.stringify(defaultData));
  }
}

function save(){
  localStorage.setItem("classclockworkData",JSON.stringify(data));
  updateAll();
}

function uid(){
  return Date.now()+Math.floor(Math.random()*1000);
}

function faculty(id){
  return data.faculty.find(x=>x.id===Number(id));
}

function room(id){
  return data.rooms.find(x=>x.id===Number(id));
}

function subject(id){
  return data.subjects.find(x=>x.id===Number(id));
}

function esc(value){
  return String(value??"").replace(/[&<>"']/g,c=>({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[c]));
}

function showToast(message){
  const toast=document.getElementById("toast");
  toast.textContent=message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>toast.classList.remove("show"),2600);
}

/* NAVIGATION */

function navTo(name){
  document.querySelectorAll(".page-section").forEach(x=>x.classList.remove("active"));
  document.getElementById(name+"Section").classList.add("active");

  document.querySelectorAll(".nav-link").forEach(x=>{
    x.classList.toggle("active",x.dataset.section===name);
  });

  document.getElementById("pageTitle").textContent =
    name[0].toUpperCase()+name.slice(1);

  document.getElementById("sidebar").classList.remove("open");

  if(name==="timetable") renderTimetable();
}

document.querySelectorAll(".nav-link").forEach(button=>{
  button.addEventListener("click",()=>navTo(button.dataset.section));
});

document.querySelectorAll("[data-go]").forEach(button=>{
  button.addEventListener("click",()=>navTo(button.dataset.go));
});

document.getElementById("mobileMenu").onclick=()=>{
  document.getElementById("sidebar").classList.toggle("open");
};

document.getElementById("loadDemo").onclick=()=>{
  data=JSON.parse(JSON.stringify(defaultData));
  save();
  showToast("Demo resources restored.");
};

/* DASHBOARD */

function updateAll(){
  updateStats();
  renderSubjects();
  renderFaculty();
  renderRooms();
  renderFilter();
  renderTimetable();
  renderPreview();
  renderWorkload();
}

function updateStats(){
  document.getElementById("subjectCount").textContent=data.subjects.length;
  document.getElementById("facultyCount").textContent=data.faculty.length;
  document.getElementById("roomCount").textContent=data.rooms.length;
  document.getElementById("clashCount").textContent=getClashes().length;

  const total=data.subjects.length+data.faculty.length+data.rooms.length;
  const filled=[data.subjects.length,data.faculty.length,data.rooms.length].filter(Boolean).length;
  const percent=Math.round(filled/3*100);

  document.getElementById("readinessPercent").textContent=percent+"%";
  document.getElementById("readinessBar").style.width=percent+"%";

  document.getElementById("readySubjects").textContent=data.subjects.length+" / "+data.subjects.length;
  document.getElementById("readyFaculty").textContent=data.faculty.length+" / "+data.faculty.length;
  document.getElementById("readyRooms").textContent=data.rooms.length+" / "+data.rooms.length;
}

function renderPreview(){
  const box=document.getElementById("overviewPreview");

  box.innerHTML=DAYS.map((day,i)=>{
    const entries=data.schedule.filter(a=>a.day===i).slice(0,2);

    return `
      <div class="mini-day">
        <strong>${day.slice(0,3)}</strong>
        ${entries.map(a=>{
          const s=subject(a.subjectId);
          return s?`<div class="mini-event ${s.type==="Lab"?"lab":""}">${esc(s.name)}</div>`:"";
        }).join("") || '<span style="color:#c2c7d0;font-size:9px">No classes</span>'}
      </div>`;
  }).join("");
}

/* SUBJECT MANAGEMENT */

function emptyRow(n,message){
  return `<tr><td colspan="${n}">${message}</td></tr>`;
}

function renderSubjects(){
  const body=document.getElementById("subjectsTable");

  body.innerHTML=data.subjects.map(s=>`
    <tr>
      <td>${esc(s.name)}</td>
      <td>${esc(s.code)}</td>
      <td>${esc(faculty(s.faculty)?.name||"Unassigned")}</td>
      <td>${esc(s.batch)}</td>
      <td>${s.periods}</td>
      <td><span class="type-pill ${s.type==="Lab"?"lab":""}">${esc(s.type)}</span></td>
      <td><button class="delete-btn" onclick="deleteResource('subjects',${s.id})">Delete</button></td>
    </tr>
  `).join("") || emptyRow(7,"No subjects added yet.");
}

/* FACULTY MANAGEMENT */

function renderFaculty(){
  document.getElementById("facultyTable").innerHTML=data.faculty.map(f=>`
    <tr>
      <td>${esc(f.name)}</td>
      <td>${esc(f.department)}</td>
      <td>${f.days.length===5?"Monday – Friday":f.days.map(d=>DAYS[d].slice(0,3)).join(", ")}</td>
      <td>${f.max} periods</td>
      <td><button class="delete-btn" onclick="deleteResource('faculty',${f.id})">Delete</button></td>
    </tr>
  `).join("") || emptyRow(5,"No faculty added yet.");
}

/* CLASSROOM MANAGEMENT */

function renderRooms(){
  document.getElementById("roomCards").innerHTML=data.rooms.map(r=>`
    <article class="room-card">
      <div class="room-icon">${r.type==="Laboratory"?"⌘":"▣"}</div>
      <h3>${esc(r.name)}</h3>
      <p>${esc(r.type)} · ${esc(r.equipment||"No special equipment")}</p>
      <div class="room-meta">
        <span>Capacity</span>
        <b>${r.capacity} students</b>
      </div>
      <button class="delete-btn" style="margin-top:12px" onclick="deleteResource('rooms',${r.id})">Delete</button>
    </article>
  `).join("") || '<div class="empty-state">No classrooms configured.</div>';
}

/* TIMETABLE FILTER */

function renderFilter(){
  const mode=document.getElementById("viewMode").value;
  const element=document.getElementById("filterSelect");
  const previous=element.value;

  const options=mode==="batch"
    ? [...new Set(data.subjects.map(s=>s.batch))]
    : data.faculty.map(f=>String(f.id));

  element.innerHTML=options.map(v=>
    mode==="batch"
      ? `<option value="${esc(v)}">${esc(v)}</option>`
      : `<option value="${v}">${esc(faculty(v)?.name||"Faculty")}</option>`
  ).join("");

  if(options.includes(previous)) element.value=previous;
}

document.getElementById("viewMode").onchange=()=>{
  renderFilter();
  renderTimetable();
};

document.getElementById("filterSelect").onchange=renderTimetable;

/* CLASH DETECTION */

function getClashes(schedule=data.schedule){
  const issues=[];

  for(let i=0;i<schedule.length;i++){
    for(let j=i+1;j<schedule.length;j++){
      const a=schedule[i],b=schedule[j];

      if(a.day!==b.day || a.period!==b.period) continue;

      const sa=subject(a.subjectId);
      const sb=subject(b.subjectId);

      if(!sa||!sb) continue;

      if(Number(sa.faculty)===Number(sb.faculty)){
        issues.push({
          a,b,
          text:`Clash: ${faculty(sa.faculty)?.name||"Faculty"} is assigned to ${sa.name} and ${sb.name} at the same time.`
        });
      }

      if(Number(a.roomId)===Number(b.roomId)){
        issues.push({
          a,b,
          text:`Clash: ${room(a.roomId)?.name||"Room"} is double-booked for ${sa.name} and ${sb.name}.`
        });
      }

      if(sa.batch===sb.batch){
        issues.push({
          a,b,
          text:`Clash: ${sa.batch} has overlapping classes ${sa.name} and ${sb.name}.`
        });
      }
    }
  }

  for(const a of schedule){
    const s=subject(a.subjectId);
    const r=room(a.roomId);

    if(s&&r&&Number(r.capacity)<Number(s.students||0)){
      issues.push({
        a,
        text:`Capacity exceeded: ${r.name} has ${r.capacity} seats for ${s.students} students (${s.name}).`
      });
    }
  }

  return issues;
}

/* TIMETABLE DISPLAY */

function renderTimetable(){
  const grid=document.getElementById("timetableGrid");
  if(!grid) return;

  const mode=document.getElementById("viewMode").value;
  const filter=document.getElementById("filterSelect").value;

  const list=data.schedule.filter(a=>{
    const s=subject(a.subjectId);
    return s&&(mode==="batch"?s.batch===filter:Number(s.faculty)===Number(filter));
  });

  let html="<div></div>";

  html+=DAYS.map(d=>`<div class="grid-head">${d}</div>`).join("");

  for(let p=0;p<6;p++){
    html+=`<div class="time-cell">${PERIODS[p]}</div>`;

    for(let d=0;d<5;d++){

      if(p===3){
        html+='<div class="break-slot">LUNCH BREAK</div>';
        continue;
      }

      const allocation=list.find(x=>x.day===d&&x.period===p);

      if(allocation){
        const s=subject(allocation.subjectId);
        const r=room(allocation.roomId);

        const conflict=getClashes().some(c=>
          c.a===allocation||c.b===allocation
        );

        html+=`
          <div class="slot" data-day="${d}" data-period="${p}"
            ondragover="allowDrop(event)"
            ondragleave="leaveDrop(event)"
            ondrop="dropClass(event)">

            <div class="class-card ${s.type==="Lab"?"lab":s.type==="Tutorial"?"tutorial":""} ${conflict?"conflict":""}"
              draggable="true"
              ondragstart="dragClass(event,${allocation.id})">

              <strong>${esc(s.name)}</strong>
              <small>${esc(faculty(s.faculty)?.name||"Faculty")}</small>
              <small>${esc(r?.name||"Room")}</small>
            </div>
          </div>`;
      }else{
        html+=`
          <div class="slot" data-day="${d}" data-period="${p}"
            ondragover="allowDrop(event)"
            ondragleave="leaveDrop(event)"
            ondrop="dropClass(event)">
            <div class="slot-empty">—</div>
          </div>`;
      }
    }
  }

  grid.innerHTML=html;

  renderAudit();
  renderWorkload();

  document.getElementById("scheduleStatus").innerHTML=
    data.schedule.length
      ? "<i></i> Schedule generated"
      : "<i></i> Ready to schedule";
}

/* AUDIT PANEL */

function renderAudit(){
  const issues=getClashes();
  const badge=document.getElementById("auditBadge");
  const list=document.getElementById("auditList");

  badge.className=issues.length?"audit-bad":"audit-ok";
  badge.textContent=issues.length
    ? `${issues.length} conflict(s)`
    : "✓ No clashes";

  list.innerHTML=issues.length
    ? issues.map(x=>`<div class="audit-item">${esc(x.text)}</div>`).join("")
    : '<div class="empty-state">Your schedule is looking good. No conflicts detected.</div>';
}

/* FACULTY WORKLOAD AND GINI */

function renderWorkload(){
  const box=document.getElementById("workloadList");
  if(!box) return;

  const values=data.faculty.map(f=>({
    name:f.name.split(" ").slice(-1)[0],
    hours:data.schedule.filter(a=>subject(a.subjectId)?.faculty===f.id).length
  }));

  const max=Math.max(1,...values.map(x=>x.hours));

  box.innerHTML=values.map(v=>`
    <div class="workload-row">
      <span>${esc(v.name)}</span>
      <div class="workload-track"><i style="width:${v.hours/max*100}%"></i></div>
      <b>${v.hours}</b>
    </div>
  `).join("") || '<div class="empty-state">Add faculty to view workload.</div>';

  const arr=values.map(v=>v.hours).sort((a,b)=>a-b);
  const n=arr.length;
  const sum=arr.reduce((a,b)=>a+b,0);
  let g=0;

  if(n&&sum){
    for(let i=0;i<n;i++){
      g+=(2*(i+1)-n-1)*arr[i];
    }
  }

  document.getElementById("giniValue").textContent=
    sum?(g/(n*sum)).toFixed(2):"0.00";
}

/* CSP TIMETABLE GENERATOR WITH MRV */

function generateSchedule(){
  if(!data.subjects.length||!data.faculty.length||!data.rooms.length){
    showToast("Add subjects, faculty and rooms first.");
    return;
  }

  const tasks=[];

  data.subjects.forEach(s=>{
    for(let k=0;k<Number(s.periods);k++){
      tasks.push({subjectId:s.id,part:k});
    }
  });

  tasks.sort((a,b)=>{
    const sa=subject(a.subjectId);
    const sb=subject(b.subjectId);

    return (sb.type==="Lab"?1:0)-(sa.type==="Lab"?1:0)
      ||sb.periods-sa.periods;
  });

  const slots=[];

  for(let d=0;d<5;d++){
    for(let p=0;p<6;p++){
      if(p!==3) slots.push({day:d,period:p});
    }
  }

  const placed=[];
  const facultyBusy=new Set();
  const roomBusy=new Set();
  const batchBusy=new Set();
  const loads={};

  data.faculty.forEach(f=>loads[f.id]=0);

  let nodes=0;

  function key(d,p){
    return d+"-"+p;
  }

  function candidates(task){
    const s=subject(task.subjectId);
    const f=faculty(s.faculty);

    return slots.filter(slot=>{
      if(!f||!f.days.includes(slot.day)||loads[f.id]>=f.max) return false;

      const k=key(slot.day,slot.period);

      if(facultyBusy.has(f.id+"-"+k)) return false;
      if(batchBusy.has(s.batch+"-"+k)) return false;

      return data.rooms.some(r=>
        r.capacity>=Number(s.students||0)
        &&(s.type!=="Lab"||r.type==="Laboratory")
        &&!roomBusy.has(r.id+"-"+k)
      );
    });
  }

  function backtrack(index){
    if(index===tasks.length) return true;
    if(++nodes>180000) return false;

    let chosenIndex=index;
    let best=null;
    let bestCount=Infinity;

    // Minimum Remaining Values heuristic
    for(let i=index;i<tasks.length;i++){
      const available=candidates(tasks[i]);

      if(available.length<bestCount){
        bestCount=available.length;
        best=available;
        chosenIndex=i;
      }

      if(bestCount===0) break;
    }

    if(!best||!best.length) return false;

    [tasks[index],tasks[chosenIndex]]=
      [tasks[chosenIndex],tasks[index]];

    const task=tasks[index];
    const s=subject(task.subjectId);
    const f=faculty(s.faculty);

    for(const slot of best){
      const k=key(slot.day,slot.period);

      const r=data.rooms.find(r=>
        r.capacity>=Number(s.students||0)
        &&(s.type!=="Lab"||r.type==="Laboratory")
        &&!roomBusy.has(r.id+"-"+k)
      );

      if(!r) continue;

      const fk=f.id+"-"+k;
      const rk=r.id+"-"+k;
      const bk=s.batch+"-"+k;

      facultyBusy.add(fk);
      roomBusy.add(rk);
      batchBusy.add(bk);
      loads[f.id]++;

      const entry={
        id:uid(),
        subjectId:s.id,
        day:slot.day,
        period:slot.period,
        roomId:r.id
      };

      placed.push(entry);

      if(backtrack(index+1)) return true;

      placed.pop();
      loads[f.id]--;

      facultyBusy.delete(fk);
      roomBusy.delete(rk);
      batchBusy.delete(bk);
    }

    [tasks[index],tasks[chosenIndex]]=
      [tasks[chosenIndex],tasks[index]];

    return false;
  }

  const success=backtrack(0);

  data.schedule=placed;
  save();

  if(success){
    showToast("Conflict-free timetable generated!");
  }else{
    showToast("Could not fit every class. Check constraints and resources.");
  }
}

document.getElementById("generateBtn").onclick=generateSchedule;

document.getElementById("generateTop").onclick=()=>{
  navTo("timetable");
  generateSchedule();
};

/* DRAG AND DROP */

window.dragClass=(e,id)=>{
  draggedId=id;
  e.dataTransfer.setData("text/plain",String(id));
  e.dataTransfer.effectAllowed="move";
};

window.allowDrop=e=>{
  e.preventDefault();
  e.currentTarget.classList.add("drop-target");
};

window.leaveDrop=e=>{
  e.currentTarget.classList.remove("drop-target");
};

window.dropClass=e=>{
  e.preventDefault();

  const slot=e.currentTarget;
  slot.classList.remove("drop-target");

  const id=Number(e.dataTransfer.getData("text/plain")||draggedId);
  const item=data.schedule.find(x=>x.id===id);

  if(!item) return;

  const day=Number(slot.dataset.day);
  const period=Number(slot.dataset.period);

  if(period===3){
    showToast("Lunch break is reserved.");
    return;
  }

  const candidate={...item,day,period};

  const trial=data.schedule
    .filter(x=>x.id!==id)
    .concat(candidate);

  if(getClashes(trial).length){
    showToast("Clash detected! Choose another time.");
    return;
  }

  item.day=day;
  item.period=period;

  save();
  showToast("Class moved successfully.");
};

/* PRINT AND PDF */

document.getElementById("printBtn").onclick=()=>{
  window.print();
};

/* ICALENDAR EXPORT */

document.getElementById("exportICS").onclick=()=>{
  if(!data.schedule.length){
    showToast("Generate a timetable before exporting.");
    return;
  }

  const start=new Date();
  const monday=new Date(start);

  monday.setDate(start.getDate()-((start.getDay()+6)%7));

  const pad=n=>String(n).padStart(2,"0");

  let lines=[
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//ClassClockwork//Timetable//EN",
    "CALSCALE:GREGORIAN"
  ];

  data.schedule.forEach(a=>{
    const s=subject(a.subjectId);
    const f=faculty(s.faculty);
    const r=room(a.roomId);

    const day=new Date(monday);
    day.setDate(monday.getDate()+a.day);

    const from=new Date(day);
    const to=new Date(day);

    from.setHours(9+a.period+(a.period>=4?1:0),0,0,0);
    to.setTime(from.getTime()+3600000);

    const fmt=d=>
      d.getFullYear()+pad(d.getMonth()+1)+pad(d.getDate())+
      "T"+pad(d.getHours())+pad(d.getMinutes())+"00";

    lines.push(
      "BEGIN:VEVENT",
      "UID:"+a.id+"@classclockwork",
      "DTSTAMP:"+fmt(new Date()),
      "DTSTART:"+fmt(from),
      "DTEND:"+fmt(to),
      "SUMMARY:"+s.name.replace(/[,;]/g," "),
      "DESCRIPTION:"+(f?.name||"")+" - "+(r?.name||""),
      "END:VEVENT"
    );
  });

  lines.push("END:VCALENDAR");

  downloadFile(
    "classclockwork-timetable.ics",
    lines.join("\r\n"),
    "text/calendar"
  );

  showToast("Calendar file exported.");
};

function downloadFile(name,content,type){
  const blob=new Blob([content],{type});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");

  a.href=url;
  a.download=name;
  a.click();

  URL.revokeObjectURL(url);
}

/* ADD RESOURCE MODALS */

let modalType="";
const backdrop=document.getElementById("modalBackdrop");

function field(name,label,type="text",required=false,placeholder=""){
  return `
    <div class="field">
      <label>${label}</label>
      <input name="${name}" type="${type}"
        ${required?"required":""}
        ${placeholder?`placeholder="${placeholder}"`:""}
        ${type==="number"?'min="1"':""}>
    </div>`;
}

function selectField(name,label,options){
  return `
    <div class="field">
      <label>${label}</label>
      <select name="${name}" required>
        ${options.map(([v,t])=>
          `<option value="${v}">${esc(t)}</option>`
        ).join("")}
      </select>
    </div>`;
}

function openModal(type){
  modalType=type;

  const fields=document.getElementById("formFields");
  const title=document.getElementById("modalTitle");

  let html="";

  if(type==="subjects"){
    title.textContent="Add subject";

    html=
      field("name","Subject name","text",true)+
      field("code","Subject code","text",true)+
      selectField("faculty","Faculty",data.faculty.map(f=>[f.id,f.name]))+
      selectField("batch","Batch",[
        ["CSE-A","CSE-A"],
        ["CSE-B","CSE-B"],
        ["CSE-C","CSE-C"]
      ])+
      field("periods","Weekly periods","number",true,"3")+
      selectField("type","Session type",[
        ["Lecture","Lecture"],
        ["Lab","Lab"],
        ["Tutorial","Tutorial"]
      ])+
      field("students","Student count","number",true,"50");

  }else if(type==="faculty"){
    title.textContent="Add faculty";

    html=
      field("name","Faculty name","text",true)+
      field("department","Department","text",true)+
      field("max","Maximum periods / week","number",true,"16")+
      `<div class="field full">
        <label>Available days</label>
        <div class="day-checks">
          ${DAYS.map((d,i)=>`
            <label style="display:inline-flex;gap:5px;margin:7px 12px 0 0">
              <input type="checkbox" name="days" value="${i}" checked>
              ${d.slice(0,3)}
            </label>
          `).join("")}
        </div>
      </div>`;

  }else{
    title.textContent="Add classroom";

    html=
      field("name","Room name","text",true)+
      selectField("type","Room type",[
        ["Classroom","Classroom"],
        ["Laboratory","Laboratory"]
      ])+
      field("capacity","Seating capacity","number",true,"60")+
      field("equipment","Equipment","text",false,"Projector, computers");
  }

  fields.innerHTML=html;
  backdrop.classList.add("show");
}

document.getElementById("addSubjectBtn").onclick=()=>openModal("subjects");
document.getElementById("addFacultyBtn").onclick=()=>openModal("faculty");
document.getElementById("addRoomBtn").onclick=()=>openModal("rooms");

function closeModal(){
  backdrop.classList.remove("show");
}

document.getElementById("closeModal").onclick=closeModal;
document.getElementById("cancelModal").onclick=closeModal;

backdrop.addEventListener("click",e=>{
  if(e.target===backdrop) closeModal();
});

/* SAVE NEW RESOURCES */

document.getElementById("resourceForm").onsubmit=e=>{
  e.preventDefault();

  const fd=new FormData(e.target);
  const v=Object.fromEntries(fd.entries());

  if(modalType==="subjects"){

    data.subjects.push({
      id:uid(),
      name:v.name,
      code:v.code,
      faculty:Number(v.faculty),
      batch:v.batch,
      periods:Math.min(6,Number(v.periods)),
      type:v.type,
      students:Number(v.students)
    });

  }else if(modalType==="faculty"){

    data.faculty.push({
      id:uid(),
      name:v.name,
      department:v.department,
      max:Number(v.max),
      days:fd.getAll("days").map(Number)
    });

  }else{

    data.rooms.push({
      id:uid(),
      name:v.name,
      type:v.type,
      capacity:Number(v.capacity),
      equipment:v.equipment
    });
  }

  closeModal();
  e.target.reset();

  save();
  showToast("Resource added successfully.");
};

/* DELETE RESOURCES */

window.deleteResource=(type,id)=>{
  if(!confirm("Delete this resource? Related timetable entries may be removed.")){
    return;
  }

  data[type]=data[type].filter(x=>x.id!==id);

  if(type==="subjects"){
    data.schedule=data.schedule.filter(x=>x.subjectId!==id);
  }

  if(type==="faculty"){
    const ids=data.subjects
      .filter(s=>s.faculty===id)
      .map(s=>s.id);

    data.schedule=data.schedule.filter(a=>!ids.includes(a.subjectId));
    data.subjects=data.subjects.filter(s=>s.faculty!==id);
  }

  if(type==="rooms"){
    data.schedule=data.schedule.filter(a=>a.roomId!==id);
  }

  save();
  showToast("Resource deleted.");
};

/* INITIALIZE APPLICATION */

updateAll();


const loginForm = document.getElementById("loginForm");

loginForm.addEventListener("submit", function(event) {

    event.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const errorMessage = document.getElementById("errorMessage");

    // Default login credentials
    const correctEmail = "yashwanth123@gmail.com";
    const correctPassword = "admin123";

    if (email === correctEmail && password === correctPassword) {

        errorMessage.style.color = "green";
        errorMessage.textContent = "Login successful!";

        // Redirect to dashboard
        window.location.href = "index.html";

    } else {

        errorMessage.style.color = "red";
        errorMessage.textContent = "Invalid email or password!";

    }

});
